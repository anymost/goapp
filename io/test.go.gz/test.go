package main

import (
 "fmt"
 "os"
 "bufio"
)


func testScanln() {
	var val1, val2, val3 string
	fmt.Println("please value")
	fmt.Scanln(&val1, &val2, &val3)
	fmt.Println(val1, val2, val3)
}

func testScanf() {
	input := "56  5212  hi"
	format := "%f  %d  %s"
	var (
		f float32
		i int
		s string
	)
	fmt.Sscanf(input, format, &f, &i, &s)
	fmt.Println(f, i, s)
}

func testBuffer()  {
	inputReader := bufio.NewReader(os.Stdin)
	value, err := inputReader.ReadString('\n')
	if err == nil {
		fmt.Println(value)
	}
}

// func main() {
// 	// testScanf()
// 	testBuffer()
// }
